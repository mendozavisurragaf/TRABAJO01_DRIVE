
public enum QuadraticExampleType {
	CreateAllPairs
}
