
public enum LinealExampleType {
	Loop,
    ContainsNeedle,
    Factorial,
    Fibonacci,
    FibonacciCache
}
