import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//CLASE Lineal
//@ Franz Mendoza Visurraga

public class Lineal {
	long[] fibonacciCache = null;

	public static void main(String[] args) throws Exception 
    {
		StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        Lineal lineal = new Lineal();
        LinealExampleType linealExampleType = LinealExampleType.ContainsNeedle;
        int nFibonacciCache = 80; //8 40 80
        lineal.fibonacciCache = new long[nFibonacciCache + 1];
        switch (linealExampleType)
        {
            case Loop:
                int n = 50;
                lineal.Loop(n);
                break;
            case ContainsNeedle:
            	
                List<Integer> numberList = new ArrayList<Integer>() ;
                numberList.add(10);
                numberList.add(18);
                numberList.add(29);
                numberList.add(0);
                numberList.add(76);
                numberList.add(79);
                
                int needle = 76;
                boolean found = lineal.ContainsNeedle(needle, numberList);
                System.out.println("Numero:"+ needle+ " esta en la lista? :"+found);
                break;
            case Factorial:
                int nFactorial = 10;
                long factorial = lineal.Factorial(nFactorial);
                System.out.println("Factorial de: "+ nFactorial+ " igual a:"+factorial);
                break;
            case Fibonacci:
                int nFibonacci = 80; //8 40 80
                for (int i = 1; i <= nFibonacci; i++)
                {
                    long fibonacci = lineal.Fibonacci(i);
                    System.out.println("Fibonacci:"+ i+ fibonacci);
                }
                break;
            case FibonacciCache:
                for (int i = 1; i <= nFibonacciCache; i++)
                {
                    long fibonacci = lineal.FibonacciCache(i);
                    System.out.println("fibonacci {0} = {1}"+ i+ fibonacci);
                }
                break;
        }
        System.out.println("Tiempo demorado en segundos:"+ Math.round(stopWatch.getElapsedTimeSecs() / 1000.0));
        Scanner s = new Scanner(System.in);
        String string = s.nextLine();
    }

   
    private void Loop(long n)
    {
        long counter = 1;
        while (counter <= n)
        {
        	System.out.println(counter);
            counter++;
        }
    }

 
    private boolean ContainsNeedle(int needle, List<Integer> numberList)
    {
        for(int item:numberList )
        {
            if (item == needle)
            {
                return true;
            }
        }
        return false;
    }

    
    private long Factorial(int n)
    {
        if (n == 1)
        {
            return 1;
        }
        return n * Factorial(n - 1);
    }

    
    private long Fibonacci(long n) throws Exception
    {
        if (n < 0)
        {
            throw new Exception("No puede ser menor de cero");
        }
        if (n <= 2)
        {
            return 1;
        }
        long fibonacci = 0;
        long previous = 1;
        long penultimate = 0;
        for (int i = 1; i <= n; i++)
        {
            penultimate = fibonacci;
            fibonacci = previous + fibonacci;
            previous = penultimate;
        }
        return fibonacci;
    }


    public long FibonacciCache(int n) throws Exception
    {
        if (n < 0)
        {
            throw new Exception("No puede ser menor de cero");
        }
        if (n <= 2)
        {
            fibonacciCache[n] = 1;
        }
        if (fibonacciCache[n] == 0)
        {
            fibonacciCache[n] = FibonacciCache(n - 1) + FibonacciCache(n - 2);
        }
        return fibonacciCache[n];
    }

}

