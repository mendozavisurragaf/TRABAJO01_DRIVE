import java.util.Scanner;


//CLASE Exponential
//@ Franz Mendoza Visurraga

public class Exponential {
	
	public static void main(String[] args) throws Exception 
    {
		StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        Exponential exponential = new Exponential();
        ExponentialExampleType exponentialExampleType = ExponentialExampleType.Fibonacci;
        switch (exponentialExampleType)
        {
            case Fibonacci:
                int n = 40; //8 40 80
                for (int i = 1; i <= n; i++)
                {
                    long fibonacci = exponential.Fibonacci(i);
                    System.out.println( i+" " + fibonacci);
                }
                break;
        }
        System.out.println("Tiempo tardado en segundos : "+ Math.round(stopWatch.getElapsedTime() / 1000.0));
        Scanner s = new Scanner(System.in);
        String string = s.nextLine();
    }

    public int Fibonacci(long n) throws Exception
    {
        if (n < 0)
        {
            throw new Exception("n can not be less than zero");
        }
        if (n <= 2)
        {
            return 1;
        }
        return Fibonacci(n - 1) + Fibonacci(n - 2);
    }
}
