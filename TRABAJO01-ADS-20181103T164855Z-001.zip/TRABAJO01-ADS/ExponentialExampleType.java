
public enum ExponentialExampleType {
	Fibonacci
}
