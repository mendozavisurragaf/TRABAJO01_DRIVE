
public enum LogarithmicExampleType {
	BinarySearch
}
