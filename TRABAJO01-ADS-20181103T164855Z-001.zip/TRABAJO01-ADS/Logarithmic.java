import java.util.Scanner;

//CLASE Quadratic
//@ Franz Mendoza Visurraga
public class Logarithmic {
	public static void main(String[] args)
     {
         Logarithmic logarithmic = new Logarithmic();
         LogarithmicExampleType quadraticExampleType = LogarithmicExampleType.BinarySearch;
         switch (quadraticExampleType)
         {
             case BinarySearch:
            	 
                 int[] numberList = { 1, 3, 3, 7, 10, 11, 16, 17, 20, 21, 25, 26, 30, 32, 34 , 35 };
                     
                 int needle = 33;
                 int min = 0;
                 int position = logarithmic.BinarySearch(numberList, needle, min, numberList.length - 1);
                 position = position +1;
                 System.out.println("Posicion donde se encuentra el n�mero:"+ position);
                 break;
         }
         Scanner s = new Scanner(System.in);
         String string = s.nextLine();
     }

     
     private int BinarySearch(int[]  numberList, int needle, int min, int max)
     {
         int midpoint = (max + min) / 2;
         if (numberList.length > 0 && numberList[midpoint] == needle)
         {
             return midpoint;
         }
         if (min >= max)
         {
             return 0;
         }
         if (numberList[midpoint] > needle)
         {
             return BinarySearch(numberList, needle, min, midpoint - 1);
         }
         return BinarySearch(numberList, needle, midpoint + 1, max);
     }
 
}
