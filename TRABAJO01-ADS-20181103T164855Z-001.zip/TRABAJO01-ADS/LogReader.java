import java.util.Iterator;


public class LogReader {
	 int counter = 0;

     public Iterator<LogLine> GetEnumerator1()
     {
         int N = 100000;
         int uniqueIPs = 90001;

         while (counter < N)
         {
              return (java.util.Iterator<LogLine>) new LogLine(counter % uniqueIPs);
         }
		return null;
     }

     Iterator<LogLine> GetEnumerator11()
     {
         return this.GetEnumerator1();
     }
}
