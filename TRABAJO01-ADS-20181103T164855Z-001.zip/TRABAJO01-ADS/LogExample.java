import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

//CLASE LogExample
//@ Franz Mendoza Visurraga
public class LogExample {
	public static void main(String[] args)
      {
		StopWatch stopWatch = new StopWatch();
          stopWatch.start();
          System.out.println("Empezando...");
          LogExample logExample = new LogExample();
          System.out.println("1:Leyendo...");
          int lineCount = logExample.ReadAllLogs();
          System.out.println("Leidos:"+ lineCount);
          System.out.println("2:Contanto...");
          int ipCount = logExample.CountUniqueIPs();
          System.out.println("N�mero de Ips unicos: " + ipCount);
          System.out.println("Tiempo de demora en segunfo"+ Math.round(stopWatch.getElapsedTimeSecs()/ 1000.0));
          Scanner s = new Scanner(System.in);
          String string = s.nextLine();
      }

      int ReadAllLogs()
      {
    	  LogLine logReader = new LogLine();
          int linesSeen = 0;
          for (LogLine line : logReader)
          {
              String ip = line.GetIP();
              linesSeen++;
          }
          return linesSeen;
      }

      int CountUniqueIPs()
      {
    	  LogLine logReader = new LogLine();
          DataStructureType dataStructureType = DataStructureType.List;
          Collection<String> ipsSeen = null;
          switch (dataStructureType)
          {
              case List: ipsSeen = new ArrayList<String>(); break;
              case HashSet: ipsSeen = new HashSet<String>(); break;
              default: ipsSeen = new ArrayList<String>(); break;
          }
          for (LogLine logLine: logReader)
          {
              String ip = logLine.GetIP();
              if (!ipsSeen.contains(ip))
              {
                  ipsSeen.add(ip);
              }
          }
          return ipsSeen.size();
      }
}
