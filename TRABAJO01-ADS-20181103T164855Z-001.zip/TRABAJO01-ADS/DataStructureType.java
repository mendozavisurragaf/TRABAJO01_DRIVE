
public enum DataStructureType {
	List,
    HashSet
}
